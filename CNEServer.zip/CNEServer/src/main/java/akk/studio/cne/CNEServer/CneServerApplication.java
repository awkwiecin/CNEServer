package akk.studio.cne.CNEServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CneServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CneServerApplication.class, args);
	}

}
